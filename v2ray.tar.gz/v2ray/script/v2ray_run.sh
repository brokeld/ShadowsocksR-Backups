#!/bin/sh
alias echo_date='echo $(date +%Y年%m月%d日\ %X):'

run_v2ray(){
	v2ray='/koolshare/bin/v2ray --config=/koolshare/bin/v2ray_config.json'
	v2ray_count=`ps -w |grep '/koolshare/bin/v2ray'|grep -v grep|grep -v watchdog|wc -l`
    if [ "$v2ray_count" -gt 0 ];then
        echo_date 已经在启动
    else
        $v2ray &
			echo $$ > /tmp/v2ray.pid
		echo_date 启动成功
    fi
}

start_v2ray(){
   echo_date ---启动进程---
   run_v2ray
   echo_date ---添加守护进程---
   if [ $(grep -c 'v2ray_watchdog.sh' /var/spool/cron/crontabs/*) -gt 0 ]; then echo_date 守护进程已添加过; else cru a v2ray_watchdog "*/5 * * * * /bin/sh /koolshare/scripts/v2ray_watchdog.sh"; fi
   echo_date ---添加GFWLIST---
   if [ ! -e "/jffs/configs/dnsmasq.d/gfwlist.conf" ];then
      ln -sf /koolshare/bin/gfwlist.conf /jffs/configs/dnsmasq.d/gfwlist.conf
      echo_date ---重启dnsmasq服务---
      service restart_dnsmasq >/dev/null 2>&1
   fi
   echo_date ---添加Ipset---
   if [ $(ipset list | grep -c "Name: gfwlist") -gt 0 ]; then echo_date ipset已添加过; else ipset -! create gfwlist nethash && ipset flush gfwlist; fi
   echo_date ---添加Iptables---
   if [ $(iptables -nvL V2RAY -t nat | grep -c "V2RAY") -gt 0 ]; then echo_date Chain已添加过; else iptables -t nat -N V2RAY >/dev/null 2>&1; fi
   if [ $(iptables -nvL V2RAY -t nat | grep -c "23454") -gt 0 ]; then echo_date Chain-rule已添加过; else iptables -t nat -A V2RAY -p tcp -m set --match-set gfwlist dst -j REDIRECT --to-ports 23454 >/dev/null 2>&1; fi
   if [ $(iptables -nvL PREROUTING -t nat | grep -c "V2RAY") -gt 0 ]; 
     then 
      echo_date PREROUTING已添加过
     else 
      KP_NU=`iptables -nvL PREROUTING -t nat |sed 1,2d | sed -n '/KOOLPROXY/='|head -n1`
	  [ "$KP_NU" == "" ] && KP_NU=0
	  INSET_NU=`expr "$KP_NU" + 1`
	  iptables -t nat -I PREROUTING "$INSET_NU" -p tcp -j V2RAY >/dev/null 2>&1
	  iptables -t nat -A OUTPUT -p tcp -j V2RAY >/dev/null 2>&1
   fi
   echo_date ---启动结束---
}

stop_v2ray(){
   echo_date ---解除守护进程和开机启动---
   sed -i '/v2ray_watchdog/d' /var/spool/cron/crontabs/* >/dev/null 2>&1
   echo_date ---删除Iptables---
   iptables -t nat -D PREROUTING -p tcp -j V2RAY >/dev/null 2>&1
   iptables -t nat -D OUTPUT -p tcp -j V2RAY >/dev/null 2>&1
   sleep 1
   iptables -t nat -F V2RAY > /dev/null 2>&1 && iptables -t nat -X V2RAY > /dev/null 2>&1
   echo_date ---删除Ipset---
   ipset -F gfwlist >/dev/null 2>&1 && ipset -X gfwlist >/dev/null 2>&1
   echo_date ---删除GFWLIST---
   if [ -e "/jffs/configs/dnsmasq.d/gfwlist.conf" ];then
      rm -rf /jffs/configs/dnsmasq.d/gfwlist.conf
      echo_date ---重启dnsmasq服务---
      service restart_dnsmasq >/dev/null 2>&1
   fi
   v2ray=$(ps | grep "v2ray" | grep -v "grep")
   if [ ! -z "$v2ray" ];then 
      echo_date 关闭v2ray进程...
      killall v2ray
   fi
   if [ -e "/koolshare/init.d/S165V2ray.sh" ];then
      rm -rf /koolshare/init.d/S165V2ray.sh
   fi
   echo_date 关闭完毕
}

case $1 in
   start)
      start_v2ray
      ;;
   stop)
      stop_v2ray
      ;;
esac

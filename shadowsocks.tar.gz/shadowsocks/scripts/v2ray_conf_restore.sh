﻿#!/bin/sh
alias echo_date='echo 【$(TZ=UTC-8 date -R +%Y年%m月%d日\ %X)】:'
cat /tmp/v2ray_conf_backup.txt |sed -i '/------Web/,$d' /tmp/v2ray_conf_backup.txt
sleep 1
cp -f /tmp/v2ray_conf_backup.txt /jffs/v2ray/config.json
echo_date 导入配置成功！
sleep 1
echo_date 完成！
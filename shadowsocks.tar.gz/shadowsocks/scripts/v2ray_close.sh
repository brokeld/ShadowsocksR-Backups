#!/bin/sh
killall v2ray

#!/bin/sh

v2ray='/jffs/v2ray/v2ray'

is_v2ray_alive() {
    v2ray_count=`ps -w |grep '/jffs/v2ray/v2ray'|grep -v grep|grep -v watchdog|wc -l`
    if [ "$v2ray_count" -eq 1 ];then
        return 0  # work ok
    else
        return 1
    fi
}

restart_v2ray() {
    killall v2ray >/dev/null 2>&1
    $v2ray &
    echo $$ > /tmp/v2ray.pid
}

stop_ss() {
    killall ss-local >/dev/null 2>&1
    killall ss-redir >/dev/null 2>&1
}

main(){
    is_v2ray_alive
    if [ "$?" -ne 0 ];then
        stop_ss
        restart_v2ray
        echo "v2ray restart at "$(date) >> /tmp/v2ray.log
    fi
}

main
